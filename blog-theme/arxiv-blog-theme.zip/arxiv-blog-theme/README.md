# arXiv Blog theme

Custom WordPress theme for [blog.arxiv.org](https://blog.arxiv.org) — a **child theme of Twenty Twenty-Five** styled with the arXiv design system's public surface.

## Why this shape

- **Child of the core default theme** — security and block-markup churn are handled upstream by WordPress core; we own only our deltas. No build step, no Node/Sass pipeline (small-team rule).
- **Design system is the source of truth** — `repos/design-system` governs every visual decision here. `assets/css/design-system.css` is a **bundled copy** of `design-system/docs/public/design-system.css` (self-hosting policy forbids loading it from an external URL). When the design system changes, re-copy the file and update the date in its header comment.
- **blog.css holds only blog-surface specifics** — the Open Blue header variant, the header search, and post-list/post styling. Everything else defers to the design system or `theme.json`.

## Documented deviations

- **Open Blue header.** DESIGN-POLICIES.md specifies a black → Repository Brown public header. Board director request (relayed and approved by Shamsi, 2026-07-31): the blog header uses Open Blue `#a5d6fe` instead — a trial. All pairings on it follow color-mapping.md's Open Blue surface rules (ink text only, Library Grey boundaries, Open Blue Bright hover).
- **Simplified nav.** Home · About arXiv · Donate + a blog-scoped search ("Search blog"). The blog's audience skews toward funders and members; the researcher workflow links (Search / Submit / Log in) stay on the main site.

## Announcement banner

Settings → **Announcement banner** (visible to Editors and up). One sentence + optional link + on/off checkbox. Renders the design system's `.ds-announcement` pattern above the header; visitor dismissal persists via `localStorage` keyed on a content hash, so publishing a new announcement re-shows the band.

## Fonts

Self-hosted in `assets/fonts/`, matching the design system's hosting spec (typography.md): IBM Plex Sans 400/500/600 (copied from `repos/arxiv-browse/browse/static/fonts/`), IBM Plex Sans Condensed 500/600 and IBM Plex Mono 400/500 (downloaded 2026-07-31 from [github.com/IBM/plex](https://github.com/IBM/plex), `packages/*/fonts/complete/woff2/`).

## Local development

No Docker needed — uses [wp-now](https://github.com/WordPress/playground-tools/tree/trunk/packages/wp-now) (WordPress Playground):

```bash
cd ~/arxiv/repos/arxiv-blog-theme && npx @wp-now/wp-now start --port 8881 --wp=7.0.4
```

wp-now detects the directory as a theme, mounts it into a throwaway WordPress, and opens it activated. Twenty Twenty-Five (the parent) ships with WordPress itself. The site is at http://localhost:8881; log in at http://localhost:8881/wp-admin as `admin` / `password` (wp-now's default).

Keep the `--wp=7.0.4` pin: without it wp-now uses the latest WordPress (7.1), where its bundled SQLite database plugin fails with "Error establishing a database connection" (found 2026-09-11). wp-now is deprecated in favor of `@wp-playground/cli`; move to it when the pin stops working.

## Deploying

Zip the theme directory and upload via wp-admin → Appearance → Themes → Add New Theme → Upload Theme:

```bash
cd ~/arxiv/repos && zip -r arxiv-blog-theme.zip arxiv-blog-theme -x "arxiv-blog-theme/.git/*"
```

## Structure

```
style.css            theme identity (child header) — intentionally no rules
theme.json           design tokens as WP presets (palette, type, spacing, widths)
functions.php        enqueues, editor styles, html.js flag
inc/banner.php       announcement banner (settings page + render + dismissal)
parts/ + patterns/   header (Open Blue bar) and footer (.ds-site-footer)
templates/           home, single, page, search (others inherit from TT5)
assets/css/          design-system.css (bundled copy) + blog.css
assets/fonts/        IBM Plex woff2 (self-hosted)
assets/images/       logo, smileybones glyph, funder wordmarks
```
