# Writing for arXiv News — a short guide

The site's design is applied automatically. If you use the right WordPress blocks while writing then no styling work is needed when writing. Here is what "the right blocks" means.

## Lists

Use the **List block** whenever you present items as a list. Do not type bullet characters (•) into a paragraph or separate lines manually. That will look similar in the editor but it will not receive the site's list styling, and screen readers cannot announce it as a list. If you have an existing paragraph of bulleted lines, select it and convert it to a List block, or paste the lines into a fresh List block.

## Quotes

Put quotations in the **Quote block** (type `/quote` on a new line). The design gives quotes an elegant treatment automatically. For the attribution, click just below the quote text where it says **"Add citation"** and type the person's name and title there — do not put the attribution inside the quote itself. The citation is styled differently from the quote on purpose.

## Images

To ensure articles have thumbnails you can either set a **featured image** on each post, or add an image to the body of the article. Featured images become the post's thumbnail on the homepage and in the "More arXiv news" suggestions, but does not appear in the body. If you do not set a featured image, the site automatically uses the first image found inside your post. If a post has no images at all, a neutral arXiv placeholder appears.

Images you place inside the article body get a frame and accent rules automatically. Please add a short caption when an image needs explanation, and always fill in the image's alt text for readers using screen readers.

## Headings

Use **Heading blocks** for section titles inside a post, starting at Heading 2 (the post title is Heading 1). Do not create headings by bolding a paragraph — bold text does not appear in the article's structure for screen readers or search engines.

## Categories

Choose the post's **categories** thoughtfully. They appear on the article page under "Filed under," and they decide which posts are suggested in the "More arXiv news" section at the bottom of each article.

## The end-of-article mark

Every article ends with a small smileybones mark after the final sentence. For posts where that tone is wrong — memorial posts especially — open the post editor's sidebar, find the **"arXiv News options"** box, and tick **"Hide the end-of-article mark."**

## The site logo and the header menu

You can change the **logo** under Appearance → Customize → Site Identity (upload an image there and the header picks it up; remove it to return to the built-in arXiv mark). The theme handles the accessibility side automatically no matter what you upload, so you only need to think about the artwork itself — ideally a transparent background, since it sits on the light blue bar.

The **header menu** is editable in the Site Editor: open Appearance → Editor → Navigation and edit the menu named "News header" (or create one — the theme shows its own default links until a menu exists). Please keep the menu short — a handful of links at most. The header is deliberately minimal, and every link added makes the others harder to find.

## The homepage banner and special message

Two site-wide messages are yours to control, both in the left menu of the WordPress dashboard under **Settings**:

- **Settings → Announcement banner** controls the thin bar above the site header. One sentence and an optional link; a checkbox turns it on and off. Readers can dismiss it, and it stays dismissed for them until you change its text.
- **Settings → Homepage** controls the welcome message and the "special message" card in the homepage's blue area. Pick the message type — Fundraising, Celebration, or Technical update — and the matching badge appears automatically. Choose Miscellaneous to use your own image, selected straight from the Media Library. In both the welcome heading and the special message heading, you can put \*stars\* around a word to set it in italic.

Note that these banners are completely unconnected to the main arXiv site banner. If they need to match it will require manual editing.

---

## One-time configurations after activating the new theme

These are WordPress.com and Jetpack settings, separate from the theme. They only need to be set once, by someone with administrator access.

**Turn these off** — they duplicate or conflict with the site's design:

- **Sharing buttons.** Jetpack adds its own "Share this" buttons below every article, duplicating the share icons the design already provides in the article sidebar. Go to **Jetpack → Settings → Sharing** and turn off "Add sharing buttons to your posts."
- **Likes.** Consider turning off. The "Like" button under articles displays a public count, and arXiv's brand guidelines state that we do not show engagement metrics anywhere. In the same Sharing settings area, we would turn off WordPress.com Likes for the site.
- **Jetpack's related posts.** The theme already shows a "More arXiv news" section at the bottom of every article. Go to **Jetpack → Settings → Traffic** and make sure "Show related content after posts" is off, so readers do not see two competing suggestion rows.
- **Subscribe pop-ups.** Keep the subscription feature itself — the article sidebar uses it — but to keep things clean check **Jetpack → Settings → Newsletter** and turn off any floating subscribe button or pop-up overlay. 
