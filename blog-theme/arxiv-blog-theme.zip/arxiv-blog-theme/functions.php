<?php
/**
 * arXiv Blog theme — child of Twenty Twenty-Five.
 *
 * All visual decisions defer to the arXiv design system
 * (repos/design-system). assets/css/design-system.css is a bundled
 * copy of the public stylesheet; blog.css holds only what is specific
 * to the blog surface. See README.md for the sync contract.
 */

// Front-end styles. design-system.css first: blog.css consumes its tokens.
add_action( 'wp_enqueue_scripts', function () {
	$version = wp_get_theme()->get( 'Version' );
	wp_enqueue_style(
		'arxiv-design-system',
		get_theme_file_uri( 'assets/css/design-system.css' ),
		array(),
		$version
	);
	wp_enqueue_style(
		'arxiv-blog',
		get_theme_file_uri( 'assets/css/blog.css' ),
		array( 'arxiv-design-system' ),
		$version
	);
} );

// Same styles in the block editor so posts preview true to the site.
add_action( 'after_setup_theme', function () {
	add_editor_style( array(
		'assets/css/design-system.css',
		'assets/css/blog.css',
	) );
} );

/*
 * Pre-paint theme boot (dark program resumed for the blog, 2026-08-07):
 * sets the html.js progressive-enhancement flag, then restores the
 * visitor's stored light/dark override before first paint (no flash).
 * With no stored choice there is no data-theme attribute, and the
 * bundled stylesheet's @media (prefers-color-scheme: dark) block
 * follows the OS/browser setting — the design system's mechanism
 * (docs/dark-mode.html). JS off → system preference still respected.
 */
add_action( 'wp_head', function () {
	?>
	<script>
	( function () {
		document.documentElement.classList.add( 'js' );
		try {
			var t = localStorage.getItem( 'arxiv-theme' );
			if ( 'light' === t || 'dark' === t ) {
				document.documentElement.setAttribute( 'data-theme', t );
			}
		} catch ( e ) {}
	} )();
	</script>
	<?php
}, 0 );

/*
 * Compact shortcode HTML: strip inter-tag newlines/indentation so
 * wpautop has nothing to convert into stray <br>/<p> tags. (It mangled
 * the subscribe button's insides once — measured, not hypothetical.)
 * Layout must come from CSS gap/margins, never inter-tag whitespace.
 */
function arxiv_blog_compact_html( $html ) {
	return preg_replace( '/\s*\n\s*/', '', $html );
}

// Editor-controlled announcement banner (.ds-announcement) + skip link.
require get_theme_file_path( 'inc/banner.php' );

// Homepage intro + special message (Settings → Homepage).
require get_theme_file_path( 'inc/homepage.php' );

// Single-post marginalia rail ([arxiv_post_rail]) + byline block.
require get_theme_file_path( 'inc/post-rail.php' );

// First-content-image fallback for card thumbnails.
require get_theme_file_path( 'inc/thumbnails.php' );

// "More arXiv news" related-posts bar ([arxiv_related_posts]).
require get_theme_file_path( 'inc/related.php' );

// Per-post end-mark toggle (meta box + body class).
require get_theme_file_path( 'inc/endmark.php' );

// Local dev only: seeds demo content in wp-now/Playground runs.
// inc/seed-demo.php is gitignored — it never ships to production.
if ( file_exists( get_theme_file_path( 'inc/seed-demo.php' ) ) ) {
	require get_theme_file_path( 'inc/seed-demo.php' );
}
