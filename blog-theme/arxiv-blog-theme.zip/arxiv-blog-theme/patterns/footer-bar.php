<?php
/**
 * Title: arXiv blog footer
 * Slug: arxiv-blog/footer-bar
 * Inserter: no
 *
 * The design system's .ds-site-footer, unchanged
 * (docs/public/footer-styles.html — "the most validated component").
 * Acknowledgment line + dot-separated nav + funders column.
 */
?>
<!-- wp:html -->
<footer class="ds-site-footer">
	<div class="ds-site-footer-grid">
		<div class="ds-site-footer-main">
			<div class="ds-site-footer-ack">
				We gratefully acknowledge support from our <strong>major funders</strong>,
				<strong>member institutions</strong>, and all contributors.
			</div>
			<nav class="ds-site-footer-links" aria-label="Site navigation">
				<a href="https://info.arxiv.org/about/index.html">About</a>
				<span class="ds-site-footer-sep" aria-hidden="true">&middot;</span>
				<a href="https://info.arxiv.org/help/index.html">Help</a>
				<span class="ds-site-footer-sep" aria-hidden="true">&middot;</span>
				<a href="https://info.arxiv.org/help/contact.html">Contact</a>
				<span class="ds-site-footer-sep" aria-hidden="true">&middot;</span>
				<a href="https://info.arxiv.org/help/subscribe.html">Subscribe</a>
				<span class="ds-site-footer-sep" aria-hidden="true">&middot;</span>
				<a href="https://info.arxiv.org/help/license/index.html">Copyright</a>
				<span class="ds-site-footer-sep" aria-hidden="true">&middot;</span>
				<a href="https://info.arxiv.org/help/policies/privacy_policy.html">Privacy</a>
				<span class="ds-site-footer-sep" aria-hidden="true">&middot;</span>
				<a href="https://info.arxiv.org/help/accessibility.html">Accessibility</a>
				<span class="ds-site-footer-sep" aria-hidden="true">&middot;</span>
				<a href="https://status.arxiv.org" target="_blank" rel="noopener noreferrer">Operational Status<span class="is-sr-only"> (opens in new tab)</span></a>
			</nav>
		</div>
		<div class="ds-site-footer-funders">
			<div class="ds-site-footer-funders-label">Major funding support from</div>
			<div class="ds-site-footer-funders-logos">
				<img class="ds-funder-logo" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/Simons-wordmark.png' ) ); ?>" alt="Simons Foundation">
				<img class="ds-funder-logo" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/Schmidt_Sciences_wordmark.png' ) ); ?>" alt="Schmidt Sciences">
			</div>
		</div>
	</div>
</footer>
<!-- /wp:html -->
