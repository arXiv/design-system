<?php
/**
 * Title: arXiv blog header bar
 * Slug: arxiv-blog/header-bar
 * Inserter: no
 *
 * The blog variant of the design system's .ds-site-header unit
 * (docs/public/header-styles.html). Construction is the documented
 * markup contract; the --blog modifier in blog.css changes only the
 * surface color (Open Blue — documented policy override) and the
 * pairings that depend on it.
 *
 * Nav is deliberately short (Home · About arXiv · Donate + blog search)
 * — the blog's audience skews to funders and members, not the
 * researcher workflow links of the main site header (Shamsi, 2026-07-31).
 */
?>
<!-- wp:html -->
<header class="ds-site-header ds-site-header--blog">
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="ds-site-header-logo" aria-label="archive news home">
		<?php
		/*
		 * Logo: editors may set one via Site Identity (the Site Logo
		 * feature's storage — theme mod / site_logo option); the theme
		 * renders it through THIS markup so the accessibility contract
		 * is code-enforced regardless of the upload: alt="archive" (the
		 * spoken form of arXiv — header behavior contract) and the
		 * link's "archive news home" label. No logo set → the bundled
		 * repository-brown mark (the documented ink pairing on Open
		 * Blue, 11.3:1; other color trials in assets/images/).
		 */
		$arxiv_logo_id  = get_theme_mod( 'custom_logo' );
		if ( ! $arxiv_logo_id ) {
			$arxiv_logo_id = (int) get_option( 'site_logo' );
		}
		$arxiv_logo_url = $arxiv_logo_id ? wp_get_attachment_image_url( $arxiv_logo_id, 'full' ) : '';
		if ( ! $arxiv_logo_url ) {
			$arxiv_logo_url = get_theme_file_uri( 'assets/images/logo_arxiv-repository-brown.png' );
		}
		?>
		<img src="<?php echo esc_url( $arxiv_logo_url ); ?>" alt="archive">
		<?php // "News" wordmark (comms 2026-08-05) beside the logo. ?>
		<span class="ds-newsmark" aria-hidden="true">News</span>
	</a>
	<?php
	/*
	 * Nav: editor-managed once a menu exists (Site Editor → Navigation
	 * creates a wp_navigation post; the newest one renders here, styled
	 * to the .ds-site-header-nav contract, hamburger disabled — the
	 * wrap is the accessible treatment). Until then, the theme's
	 * default links render. Keep the menu SHORT (nav-brevity policy).
	 */
	$arxiv_nav = get_posts( array(
		'post_type'   => 'wp_navigation',
		'numberposts' => 1,
		'post_status' => 'publish',
	) );
	if ( $arxiv_nav ) {
		echo '<div class="ds-site-header-nav ds-site-header-nav--editor">';
		echo do_blocks( '<!-- wp:navigation {"ref":' . (int) $arxiv_nav[0]->ID . ',"overlayMenu":"never"} /-->' );
		echo '</div>';
	} else {
		?>
		<nav class="ds-site-header-nav" aria-label="Main navigation">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>
			<a href="https://info.arxiv.org/about/index.html">About arXiv</a>
			<a href="<?php echo esc_url( arxiv_blog_homepage_get()['subscribe_url'] ); ?>">Subscribe</a>
			<a href="https://info.arxiv.org/about/donate.html">Donate</a>
		</nav>
		<?php
	}
	?>
	<?php // Theme toggle: ONE bare icon showing the current state; click
	      // cycles light → dark → auto (info.arxiv.org convention).
	      // JS-only; without JS the OS preference applies. ?>
	<?php // Icons: the Material brightness family (brightness_high /
	      // brightness_4 / brightness_auto, Apache 2.0) — one sunburst
	      // silhouette with a ring, crescent, or "A" center. Deliberate
	      // continuity exception to the Lucide-only rule: matches the
	      // toggle already in use on info.arxiv.org. ?>
	<div class="arxiv-theme-toggle">
		<button type="button" data-mode="auto" aria-label="Color theme">
			<svg class="arxiv-icon-sun" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M20 8.69V4h-4.69L12 .69 8.69 4H4v4.69L.69 12 4 15.31V20h4.69L12 23.31 15.31 20H20v-4.69L23.31 12 20 8.69zM12 18c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6zm0-10c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4z"/></svg>
			<svg class="arxiv-icon-moon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M20 8.69V4h-4.69L12 .69 8.69 4H4v4.69L.69 12 4 15.31V20h4.69L12 23.31 15.31 20H20v-4.69L23.31 12 20 8.69zM12 18c-.89 0-1.74-.2-2.5-.55C11.56 16.5 13 14.42 13 12s-1.44-4.5-3.5-5.45C10.26 6.2 11.11 6 12 6c3.31 0 6 2.69 6 6s-2.69 6-6 6z"/></svg>
			<svg class="arxiv-icon-auto" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M20 8.69V4h-4.69L12 .69 8.69 4H4v4.69L.69 12 4 15.31V20h4.69L12 23.31 15.31 20H20v-4.69L23.31 12 20 8.69zM14.3 16l-.7-2h-3.2l-.7 2H7.8L11 7h2l3.2 9h-1.9z"/></svg>
		</button>
	</div>
	<script>
	( function () {
		var btn = document.querySelector( '.arxiv-theme-toggle button' );
		if ( ! btn ) { return; }
		var KEY   = 'arxiv-theme';
		var ORDER = [ 'light', 'dark', 'auto' ];
		var NAMES = { light: 'light', dark: 'dark', auto: 'match the system' };
		function apply( value ) {
			if ( 'light' === value || 'dark' === value ) {
				document.documentElement.setAttribute( 'data-theme', value );
			} else {
				document.documentElement.removeAttribute( 'data-theme' );
				value = 'auto';
			}
			btn.setAttribute( 'data-mode', value );
			var next = ORDER[ ( ORDER.indexOf( value ) + 1 ) % ORDER.length ];
			btn.setAttribute( 'aria-label',
				'Color theme: ' + NAMES[ value ] + '. Activate to ' +
				( 'auto' === next ? NAMES[ next ] : 'switch to ' + NAMES[ next ] ) + '.' );
		}
		var saved = null;
		try { saved = localStorage.getItem( KEY ); } catch ( e ) {}
		apply( saved );
		btn.addEventListener( 'click', function () {
			var next = ORDER[ ( ORDER.indexOf( btn.getAttribute( 'data-mode' ) ) + 1 ) % ORDER.length ];
			try {
				if ( 'auto' === next ) { localStorage.removeItem( KEY ); }
				else { localStorage.setItem( KEY, next ); }
			} catch ( e ) {}
			apply( next );
		} );
	} )();
	</script>
	<form role="search" method="get" class="ds-blog-search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<label for="arxiv-blog-search-field" class="is-sr-only">Search blog</label>
		<input type="search" id="arxiv-blog-search-field" name="s" placeholder="Search blog" value="<?php echo esc_attr( get_search_query() ); ?>">
		<button type="submit">
			<span class="is-sr-only">Search</span>
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
				<circle cx="11" cy="11" r="8"/>
				<line x1="21" y1="21" x2="16.65" y2="16.65"/>
			</svg>
		</button>
	</form>

	<?php
	/*
	 * Phone-width header (≤599px): nav and search collapse behind a
	 * search icon and a hamburger, each opening a native <dialog>
	 * (z-layer policy: modals use the top layer). Per the header
	 * contract, the collapse activates ONLY when the script below runs
	 * (.is-collapsible) — no JS leaves the accessible wrap. Hamburger
	 * is the policy's permitted last-resort at very narrow widths.
	 */
	?>
	<button type="button" class="arxiv-header-icon arxiv-open-search" aria-label="Search" aria-haspopup="dialog">
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
	</button>
	<button type="button" class="arxiv-header-icon arxiv-open-menu" aria-label="Menu" aria-haspopup="dialog">
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
	</button>

	<dialog class="arxiv-header-dialog arxiv-search-dialog" aria-label="Search the blog">
		<button type="button" class="arxiv-dialog-close" aria-label="Close">&times;</button>
		<form role="search" method="get" class="arxiv-dialog-search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label for="arxiv-mobile-search-field" class="is-sr-only">Search blog</label>
			<input type="search" id="arxiv-mobile-search-field" name="s" placeholder="Search blog" autofocus>
			<button type="submit" class="ds-btn ds-btn-secondary"><?php esc_html_e( 'Search', 'arxiv-blog' ); ?></button>
		</form>
	</dialog>
	<dialog class="arxiv-header-dialog arxiv-menu-dialog" aria-label="Menu">
		<button type="button" class="arxiv-dialog-close" aria-label="Close">&times;</button>
		<div class="arxiv-menu-dialog-body"><?php // the header nav is cloned in by the script ?></div>
	</dialog>

	<script>
	( function () {
		var header    = document.querySelector( '.ds-site-header--blog' );
		if ( ! header ) { return; }
		var searchBtn = header.querySelector( '.arxiv-open-search' );
		var menuBtn   = header.querySelector( '.arxiv-open-menu' );
		var searchDlg = header.querySelector( '.arxiv-search-dialog' );
		var menuDlg   = header.querySelector( '.arxiv-menu-dialog' );
		if ( ! searchBtn || ! menuBtn || ! searchDlg || ! menuDlg || ! searchDlg.showModal ) { return; }
		header.classList.add( 'is-collapsible' );
		var navSrc = header.querySelector( '.ds-site-header-nav' );
		var body   = menuDlg.querySelector( '.arxiv-menu-dialog-body' );
		if ( navSrc && body && ! body.firstChild ) {
			var clone = navSrc.cloneNode( true );
			// Escape the design system's .is-collapsible hide rules —
			// inside the dialog this is just a vertical menu.
			clone.classList.remove( 'ds-site-header-nav', 'ds-site-header-nav--editor' );
			clone.classList.add( 'arxiv-menu-clone' );
			body.appendChild( clone );
		}
		function wire( btn, dlg ) {
			btn.addEventListener( 'click', function () { dlg.showModal(); } );
			dlg.addEventListener( 'click', function ( e ) { if ( e.target === dlg ) { dlg.close(); } } );
			var close = dlg.querySelector( '.arxiv-dialog-close' );
			if ( close ) { close.addEventListener( 'click', function () { dlg.close(); } ); }
		}
		wire( searchBtn, searchDlg );
		wire( menuBtn, menuDlg );
	} )();
	</script>
</header>
<!-- /wp:html -->
