<?php
/**
 * Social share metadata — Open Graph + the one Twitter tag that matters.
 *
 * Theme-native because the live site emitted NO og: tags at all
 * (Jetpack's ride along with its Sharing module, which the design
 * intentionally leaves off), so LinkedIn/Slack/iMessage previews fell
 * back to bare HTML (found by comms, 2026-08-26).
 *
 * Practice followed (researched 2026-08): one 1200x630 (1.91:1) image
 * suits every platform incl. LinkedIn; og:title/type/image/url are the
 * required set, plus description + site_name; declare image dimensions
 * so the first share renders without waiting for a scrape; and set
 * twitter:card=summary_large_image explicitly — X falls back to og:*
 * for content but defaults to the SMALL card without it.
 *
 * Image choice per post: featured image, else first content image
 * (same fallback order readers see on the homepage), else the branded
 * default card (assets/images/og-card-default.png, regenerate with
 * scripts/make-og-card.py).
 */

// Belt and braces: if Jetpack's Open Graph ever activates, keep it from
// double-emitting alongside ours.
add_filter( 'jetpack_enable_open_graph', '__return_false' );

add_action( 'wp_head', function () {
	$site  = get_bloginfo( 'name' );
	$title = $site;
	$desc  = get_bloginfo( 'description' );
	$type  = 'website';
	$url   = is_front_page() ? home_url( '/' ) : '';
	$img   = get_theme_file_uri( 'assets/images/og-card-default.png' );
	$img_w = 1200;
	$img_h = 630;
	$img_alt = 'arXiv';

	if ( is_singular() ) {
		$post_id = get_queried_object_id();
		$title   = get_the_title( $post_id );
		$url     = get_permalink( $post_id );
		$excerpt = wp_strip_all_tags( get_the_excerpt( $post_id ) );
		if ( '' !== $excerpt ) {
			$desc = wp_trim_words( $excerpt, 32 );
		}
		if ( is_singular( 'post' ) ) {
			$type = 'article';
		}
		$thumb_id = get_post_thumbnail_id( $post_id );
		if ( $thumb_id ) {
			$src = wp_get_attachment_image_src( $thumb_id, 'full' );
			if ( $src ) {
				list( $img, $img_w, $img_h ) = $src;
				$alt     = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true );
				$img_alt = $alt ? $alt : $title;
			}
		} elseif ( function_exists( 'arxiv_blog_first_content_image' ) ) {
			$first = arxiv_blog_first_content_image( $post_id );
			if ( '' !== $first ) {
				$img     = $first;
				$img_w   = 0; // dimensions unknown for a content URL
				$img_h   = 0;
				$img_alt = $title;
			}
		}
	}

	$tags = array(
		'og:site_name' => $site,
		'og:locale'    => 'en_US',
		'og:type'      => $type,
		'og:title'     => $title,
	);
	if ( '' !== $desc ) {
		$tags['og:description'] = $desc;
	}
	if ( '' !== $url ) {
		$tags['og:url'] = $url;
	}
	$tags['og:image'] = $img;
	if ( $img_w && $img_h ) {
		$tags['og:image:width']  = $img_w;
		$tags['og:image:height'] = $img_h;
	}
	$tags['og:image:alt'] = $img_alt;
	if ( 'article' === $type ) {
		$tags['article:published_time'] = get_the_date( 'c', $post_id );
		$tags['article:modified_time']  = get_the_modified_date( 'c', $post_id );
	}

	echo "\n";
	foreach ( $tags as $property => $content ) {
		printf(
			'<meta property="%s" content="%s">' . "\n",
			esc_attr( $property ),
			esc_attr( $content )
		);
	}
	// name= (not property=) per Twitter's spec; content falls back to og:*.
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
}, 4 );
