<?php
/**
 * Social share metadata — Open Graph + the one Twitter tag that matters.
 *
 * Theme-native because the live site emitted NO og: tags at all
 * (Jetpack's ride along with its Sharing module, which the design
 * intentionally leaves off), so LinkedIn/Slack/iMessage previews fell
 * back to bare HTML (found by comms, 2026-08-26).
 *
 * Practice followed (researched 2026-08): one 1200x630 (1.91:1) image
 * suits every platform incl. LinkedIn; og:title/type/image/url are the
 * required set, plus description + site_name; declare image dimensions
 * so the first share renders without waiting for a scrape; and set
 * twitter:card=summary_large_image explicitly — X falls back to og:*
 * for content but defaults to the SMALL card without it.
 *
 * Image choice per post: featured image, else first content image
 * (same fallback order readers see on the homepage), else the branded
 * default card (assets/images/og-card-default.png, regenerate with
 * scripts/make-og-card.py).
 */

// Belt and braces: if Jetpack's Open Graph ever activates, keep it from
// double-emitting alongside ours.
add_filter( 'jetpack_enable_open_graph', '__return_false' );

/**
 * og:image source for an attachment: origin URL with NO query string,
 * dimensions from stored metadata. On WordPress.com,
 * wp_get_attachment_image_src returns Photon URLs with multiple params
 * (?fit=W%2CH&ssl=1) whose escaped ampersand LinkedIn's scraper
 * mishandles — its inspector reported "No image found" for exactly
 * those while the theme's single-param card URL worked (2026-08-26).
 *
 * Prefers a generated intermediate between 1200 and 2048px over a
 * huge original (closer to the 1200x630 platform ideal, lighter to
 * scrape); a small original is never downgraded to a thumbnail.
 *
 * @return array|false [url, width, height] like the core src helpers.
 */
function arxiv_blog_og_attachment( $att_id ) {
	$url = wp_get_attachment_url( $att_id );
	if ( ! $url ) {
		return false;
	}
	$url  = strtok( $url, '?' ); // no params — nothing for a scraper to mangle
	$meta = wp_get_attachment_metadata( $att_id );
	$w    = is_array( $meta ) && ! empty( $meta['width'] ) ? (int) $meta['width'] : 0;
	$h    = is_array( $meta ) && ! empty( $meta['height'] ) ? (int) $meta['height'] : 0;
	if ( max( $w, $h ) > 2048 ) {
		$best = null;
		foreach ( is_array( $meta ) && ! empty( $meta['sizes'] ) ? $meta['sizes'] : array() as $size ) {
			if ( empty( $size['file'] ) || empty( $size['width'] ) || empty( $size['height'] ) ) {
				continue;
			}
			// Largest generated size that fits 2048, no thumbnails.
			if ( max( $size['width'], $size['height'] ) <= 2048 && $size['width'] >= 800
				&& ( ! $best || $size['width'] > $best['width'] ) ) {
				$best = $size;
			}
		}
		if ( $best ) {
			$url = dirname( $url ) . '/' . $best['file'];
			$w   = (int) $best['width'];
			$h   = (int) $best['height'];
		} elseif ( function_exists( 'jetpack_photon_url' ) && $w > 1200 ) {
			/*
			 * WordPress.com generates NO physical intermediate files
			 * (checked via the live REST API, 2026-08-27) — Photon
			 * resizes on the fly instead. Request w=1200: a SINGLE
			 * query param, so no ampersand for scrapers to mangle,
			 * and comfortably under WhatsApp's 500 KB preview cap.
			 */
			$h   = (int) round( $h * 1200 / $w );
			$w   = 1200;
			$url = jetpack_photon_url( $url, array( 'w' => 1200 ) );
		}
	}
	return array( $url, $w, $h );
}

/**
 * Platform-safe description length: most platforms truncate hard past
 * ~200 chars (opengraph.to flagged a 203-char one); 110-160 is the
 * recommended band. Cuts at a word boundary.
 */
function arxiv_blog_og_trim( $text ) {
	$text = trim( $text );
	if ( mb_strlen( $text ) <= 158 ) {
		return $text;
	}
	$cut = mb_substr( $text, 0, 158 );
	$sp  = mb_strrpos( $cut, ' ' );
	if ( $sp ) {
		$cut = mb_substr( $cut, 0, $sp );
	}
	return rtrim( $cut, ' ,;:.' ) . '…';
}

add_action( 'wp_head', function () {
	$site  = get_bloginfo( 'name' );
	$title = $site;
	$desc  = get_bloginfo( 'description' );
	// LinkedIn wants ≥100 chars of description; the tagline is ~36. The
	// homepage's welcome body (Settings → Homepage) is longer, editor-
	// controlled, and already approved copy — use it on the front page.
	if ( is_front_page() && function_exists( 'arxiv_blog_homepage_get' ) ) {
		$body = trim( arxiv_blog_homepage_get()['intro_body'] );
		if ( '' !== $body ) {
			$desc = $body;
		}
	}
	$type  = 'website';
	$url   = is_front_page() ? home_url( '/' ) : '';
	// Version query: CDNs and scrapers cache og images hard — a new
	// theme version makes the card a fresh URL everywhere.
	$img   = get_theme_file_uri( 'assets/images/og-card-default.png' )
		. '?v=' . rawurlencode( wp_get_theme()->get( 'Version' ) );
	$img_w = 1200;
	$img_h = 630;
	$img_alt = 'arXiv';

	if ( is_singular() ) {
		$post_id = get_queried_object_id();
		$title   = get_the_title( $post_id );
		$url     = get_permalink( $post_id );
		$excerpt = wp_strip_all_tags( get_the_excerpt( $post_id ) );
		if ( '' !== $excerpt ) {
			$desc = arxiv_blog_og_trim( $excerpt );
		}
		if ( is_singular( 'post' ) ) {
			$type = 'article';
		}
		$thumb_id = get_post_thumbnail_id( $post_id );
		if ( $thumb_id ) {
			$src = arxiv_blog_og_attachment( $thumb_id );
			if ( $src ) {
				list( $img, $img_w, $img_h ) = $src;
				$alt     = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true );
				$img_alt = $alt ? $alt : $title;
			}
		} elseif ( function_exists( 'arxiv_blog_first_content_image' ) ) {
			$first = arxiv_blog_first_content_image( $post_id );
			if ( '' !== $first ) {
				/*
				 * LinkedIn skips images with undeclared dimensions
				 * ("No image found", Shamsi 2026-08-26), so resolve the
				 * content URL back to its Media Library attachment:
				 * strip resize query (?w=792) and -WxH size suffixes,
				 * then serve the original with its real dimensions.
				 */
				$clean = strtok( $first, '?' );
				$orig  = preg_replace( '/-\d+x\d+(\.[a-z]{3,4})$/i', '$1', $clean );
				$att   = attachment_url_to_postid( $orig );
				if ( ! $att && $orig !== $clean ) {
					$att = attachment_url_to_postid( $clean );
				}
				$src = $att ? arxiv_blog_og_attachment( $att ) : false;
				if ( $src ) {
					list( $img, $img_w, $img_h ) = $src;
					$alt     = get_post_meta( $att, '_wp_attachment_image_alt', true );
					$img_alt = $alt ? $alt : $title;
				} else {
					$img     = $clean; // not in the library — best effort
					$img_w   = 0;
					$img_h   = 0;
					$img_alt = $title;
				}
			}
		}
	}

	$tags = array(
		'og:site_name' => $site,
		'og:locale'    => 'en_US',
		'og:type'      => $type,
		'og:title'     => $title,
	);
	if ( '' !== $desc ) {
		$tags['og:description'] = $desc;
	}
	if ( '' !== $url ) {
		$tags['og:url'] = $url;
	}
	$tags['og:image'] = $img;
	if ( $img_w && $img_h ) {
		$tags['og:image:width']  = $img_w;
		$tags['og:image:height'] = $img_h;
	}
	$tags['og:image:alt'] = $img_alt;
	if ( 'article' === $type ) {
		$tags['article:published_time'] = get_the_date( 'c', $post_id );
		$tags['article:modified_time']  = get_the_modified_date( 'c', $post_id );
	}

	echo "\n";
	foreach ( $tags as $property => $content ) {
		printf(
			'<meta property="%s" content="%s">' . "\n",
			esc_attr( $property ),
			esc_attr( $content )
		);
	}
	// name= (not property=) per Twitter's spec; content falls back to og:*.
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	echo '<meta name="twitter:site" content="@arxiv">' . "\n"; // handle confirmed by Shamsi 2026-08-26
	// Mobile browser chrome matches the Open Blue header bar (both modes).
	echo '<meta name="theme-color" content="#a5d6fe">' . "\n";
	if ( is_singular( 'post' ) ) {
		/*
		 * Search-snippet description from the same excerpt. NOTE:
		 * WordPress.com also emits a meta description (currently just
		 * the title); ours prints earlier, and duplicate descriptions
		 * are benign — engines take the first/better one.
		 */
		printf( '<meta name="description" content="%s">' . "\n", esc_attr( $desc ) );
		/*
		 * NewsArticle structured data (JSON-LD) from the values already
		 * gathered above — what search engines want from a news site.
		 */
		$schema = array(
			'@context'         => 'https://schema.org',
			'@type'            => 'NewsArticle',
			'headline'         => wp_html_excerpt( $title, 110 ),
			'description'      => $desc,
			'mainEntityOfPage' => $url,
			'image'            => array( $img ),
			'datePublished'    => get_the_date( 'c', $post_id ),
			'dateModified'     => get_the_modified_date( 'c', $post_id ),
			'author'           => array(
				array(
					'@type' => 'Person',
					'name'  => get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $post_id ) ),
					'url'   => get_author_posts_url( (int) get_post_field( 'post_author', $post_id ) ),
				),
			),
			'publisher'        => array(
				'@type' => 'Organization',
				'name'  => 'arXiv',
				'logo'  => array(
					'@type' => 'ImageObject',
					'url'   => get_theme_file_uri( 'assets/images/logo_arxiv-repository-brown.png' ),
				),
			),
		);
		echo '<script type="application/ld+json">'
			. wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
			. '</script>' . "\n";
	}
}, 4 );
