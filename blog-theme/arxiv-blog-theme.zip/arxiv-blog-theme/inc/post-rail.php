<?php
/**
 * Post rail (marginalia) — [arxiv_post_rail] shortcode.
 *
 * Rendered beside single posts: categories, share links, subscribe.
 * A shortcode (not a theme pattern) because pattern PHP executes once
 * at registration, outside the loop — per-post values like
 * get_permalink() need render-time execution.
 *
 * Deliberately NOT sticky — sticky chrome is reader-only
 * (DESIGN-POLICIES, Chrome and interaction structure). Share links
 * are plain intent URLs; no third-party scripts or embeds.
 */

/*
 * Byline — "By Kat Boboris · July 30th 2026".
 * Serif row: italic author, real <time>, superscript date ordinal.
 *
 * Rendered by the arxiv/post-byline BLOCK, which receives the postId
 * from block context — the only reliable per-post source inside a
 * query loop. (A shortcode reading the global $post rendered every
 * homepage card with the first post's date on WordPress.com, where
 * Gutenberg's loop doesn't sync globals the way core did locally.)
 */
function arxiv_blog_byline_html( $post_id ) {
	$post_id = (int) $post_id;
	if ( ! $post_id || 'post' !== get_post_type( $post_id ) ) {
		return '';
	}
	$date_html = get_the_date( 'F j', $post_id )
		. '<sup class="arxiv-ordinal">' . get_the_date( 'S', $post_id ) . '</sup> '
		. get_the_date( 'Y', $post_id );
	$author = get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $post_id ) );
	return arxiv_blog_compact_html(
		'<p class="arxiv-post-byline">'
		. '<span class="arxiv-byline-author">By ' . esc_html( $author ) . '</span>'
		. '<span class="arxiv-byline-sep" aria-hidden="true">&middot;</span>'
		. '<time datetime="' . esc_attr( get_the_date( 'c', $post_id ) ) . '">' . $date_html . '</time>'
		. '</p>'
	);
}

add_action( 'init', function () {
	register_block_type( 'arxiv/post-byline', array(
		'uses_context'    => array( 'postId' ),
		'render_callback' => function ( $attributes, $content, $block ) {
			$post_id = isset( $block->context['postId'] ) ? (int) $block->context['postId'] : get_the_ID();
			return arxiv_blog_byline_html( $post_id );
		},
	) );
} );

// Back-compat: the old shortcode delegates (correct on singular pages).
add_shortcode( 'arxiv_post_byline', function () {
	return arxiv_blog_byline_html( get_the_ID() );
} );

add_shortcode( 'arxiv_post_rail', function () {
	if ( ! is_singular( 'post' ) ) {
		return '';
	}
	$rail_url  = get_permalink();
	$enc_url   = rawurlencode( $rail_url );
	$enc_title = rawurlencode( get_the_title() );
	$subscribe = function_exists( 'arxiv_blog_homepage_get' )
		? arxiv_blog_homepage_get()['subscribe_url']
		: '/feed/';
	$new_tab = ' target="_blank" rel="noopener noreferrer"';

	ob_start();
	?>
	<aside class="arxiv-rail" aria-label="About this post">
		<?php $categories = get_the_category(); if ( $categories ) : ?>
		<div class="arxiv-rail-section">
			<h2 class="arxiv-rail-heading"><?php esc_html_e( 'Filed under', 'arxiv-blog' ); ?></h2>
			<?php // Lozenges in the arXiv-chrome tint family — the neutral
			      // register (works on memorials; Smileybones Yellow stays
			      // reserved for the homepage featured rule). ?>
			<ul class="arxiv-cat-lozenges">
				<?php foreach ( $categories as $cat ) : ?>
					<li><a class="arxiv-lozenge" href="<?php echo esc_url( get_category_link( $cat ) ); ?>"><?php echo esc_html( $cat->name ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php endif; ?>
		<div class="arxiv-rail-section">
			<h2 class="arxiv-rail-heading"><?php esc_html_e( 'Share', 'arxiv-blog' ); ?></h2>
			<?php // Compact icon row. Brand glyphs inlined (self-hosted policy;
			      // Lucide carries no brand icons). Each target is ≥24px (2.5.8). ?>
			<ul class="arxiv-rail-share">
				<li><a href="<?php echo esc_url( 'https://bsky.app/intent/compose?text=' . $enc_title . '%20' . $enc_url ); ?>"<?php echo $new_tab; ?> aria-label="<?php esc_attr_e( 'Share on Bluesky (opens in new tab)', 'arxiv-blog' ); ?>"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M12 10.8c-1.087-2.114-4.046-6.053-6.798-7.995C2.566.944 1.561 1.266.902 1.565.139 1.908 0 3.08 0 3.768c0 .69.378 5.65.624 6.479.815 2.736 3.713 3.66 6.383 3.364.136-.02.275-.039.415-.056-.138.022-.276.04-.415.056-3.912.58-7.387 2.005-2.83 7.078 5.013 5.19 6.87-1.113 7.823-4.308.953 3.195 2.05 9.271 7.733 4.308 4.267-4.308 1.172-6.498-2.74-7.078a8.741 8.741 0 0 1-.415-.056c.14.017.279.036.415.056 2.67.297 5.568-.628 6.383-3.364.246-.828.624-5.79.624-6.478 0-.69-.139-1.861-.902-2.206-.659-.298-1.664-.62-4.3 1.24C16.046 4.748 13.087 8.687 12 10.8Z"/></svg></a></li>
				<li><a href="<?php echo esc_url( 'https://www.linkedin.com/sharing/share-offsite/?url=' . $enc_url ); ?>"<?php echo $new_tab; ?> aria-label="<?php esc_attr_e( 'Share on LinkedIn (opens in new tab)', 'arxiv-blog' ); ?>"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.225 0z"/></svg></a></li>
				<li><a href="<?php echo esc_url( 'https://www.facebook.com/sharer/sharer.php?u=' . $enc_url ); ?>"<?php echo $new_tab; ?> aria-label="<?php esc_attr_e( 'Share on Facebook (opens in new tab)', 'arxiv-blog' ); ?>"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg></a></li>
				<li><a href="<?php echo esc_url( 'https://twitter.com/intent/tweet?url=' . $enc_url . '&text=' . $enc_title ); ?>"<?php echo $new_tab; ?> aria-label="<?php esc_attr_e( 'Share on X (opens in new tab)', 'arxiv-blog' ); ?>"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg></a></li>
				<li><a href="<?php echo esc_url( 'mailto:?subject=' . $enc_title . '&body=' . $enc_url ); ?>" aria-label="<?php esc_attr_e( 'Share by email', 'arxiv-blog' ); ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/></svg></a></li>
				<li>
					<button type="button" class="arxiv-copy-link" data-url="<?php echo esc_attr( $rail_url ); ?>" aria-label="<?php esc_attr_e( 'Copy link', 'arxiv-blog' ); ?>">
						<svg class="arxiv-icon-link" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
						<svg class="arxiv-icon-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M20 6 9 17l-5-5"/></svg>
					</button>
					<span class="is-sr-only" aria-live="polite" data-copy-status></span>
				</li>
			</ul>
		</div>
		<div class="arxiv-rail-section">
			<h2 class="arxiv-rail-heading"><?php esc_html_e( 'Stay updated', 'arxiv-blog' ); ?></h2>
			<p><?php esc_html_e( 'Hear news from arXiv first.', 'arxiv-blog' ); ?></p>
			<?php if ( shortcode_exists( 'jetpack_subscription_form' ) ) : ?>
				<?php // Production (WordPress.com/Jetpack): the real email-subscribe
				      // form, wrapped in our class so the rail styles reach it. ?>
				<div class="arxiv-rail-subscribe arxiv-rail-subscribe--jetpack">
					<?php echo do_shortcode( '[jetpack_subscription_form show_subscribers_total="false" title="" subscribe_text=""]' ); ?>
				</div>
			<?php else : ?>
				<?php // Local/no-Jetpack fallback: hands the email to the subscribe page. ?>
				<form class="arxiv-rail-subscribe" method="get" action="<?php echo esc_url( $subscribe ); ?>">
					<label class="is-sr-only" for="arxiv-rail-email"><?php esc_html_e( 'Email address', 'arxiv-blog' ); ?></label>
					<input type="email" id="arxiv-rail-email" name="email" placeholder="<?php esc_attr_e( 'Email address', 'arxiv-blog' ); ?>" required>
					<button type="submit" class="ds-btn ds-btn-secondary"><?php esc_html_e( 'Subscribe', 'arxiv-blog' ); ?></button>
				</form>
			<?php endif; ?>
		</div>
	</aside>
	<script>
	( function () {
		var btn = document.querySelector( '.arxiv-copy-link' );
		var status = document.querySelector( '[data-copy-status]' );
		if ( ! btn || ! navigator.clipboard ) { return; }
		btn.addEventListener( 'click', function () {
			navigator.clipboard.writeText( btn.getAttribute( 'data-url' ) ).then( function () {
				btn.classList.add( 'is-copied' );
				if ( status ) { status.textContent = '<?php echo esc_js( __( 'Link copied', 'arxiv-blog' ) ); ?>'; }
				setTimeout( function () {
					btn.classList.remove( 'is-copied' );
					if ( status ) { status.textContent = ''; }
				}, 1600 );
			} );
		} );
	} )();
	</script>
	<?php
	return arxiv_blog_compact_html( ob_get_clean() );
} );
