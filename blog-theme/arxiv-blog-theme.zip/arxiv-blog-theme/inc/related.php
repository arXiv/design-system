<?php
/**
 * [arxiv_related_posts] — "More arXiv news" bar at the bottom of
 * single posts: three cards sharing the current post's categories
 * (topped up with recent posts when a category runs thin). Fully
 * automatic — no editorial upkeep.
 */

add_shortcode( 'arxiv_related_posts', function () {
	if ( ! is_singular( 'post' ) ) {
		return '';
	}
	$post_id = get_the_ID();
	$cats    = wp_get_post_categories( $post_id );

	$related = get_posts( array(
		'numberposts'         => 3,
		'exclude'             => array( $post_id ),
		'category__in'        => $cats ? $cats : array(),
		'ignore_sticky_posts' => true,
	) );
	if ( count( $related ) < 3 ) {
		$exclude = array_merge( array( $post_id ), wp_list_pluck( $related, 'ID' ) );
		$fill    = get_posts( array(
			'numberposts' => 3 - count( $related ),
			'exclude'     => $exclude,
		) );
		$related = array_merge( $related, $fill );
	}
	if ( ! $related ) {
		return '';
	}

	$items = '';
	foreach ( $related as $rel ) {
		$rel_id = $rel->ID;
		$thumb  = get_the_post_thumbnail_url( $rel_id, 'medium_large' );
		if ( ! $thumb ) {
			$thumb = arxiv_blog_first_content_image( $rel_id );
		}
		$media = $thumb
			? '<img src="' . esc_url( $thumb ) . '" alt="" loading="lazy">'
			: '<span class="arxiv-related-placeholder" aria-hidden="true"></span>';
		$date  = get_the_date( 'F j', $rel_id )
			. '<sup class="arxiv-ordinal">' . get_the_date( 'S', $rel_id ) . '</sup> '
			. get_the_date( 'Y', $rel_id );
		$items .= '<li>'
			. '<a class="arxiv-related-link" href="' . esc_url( get_permalink( $rel_id ) ) . '">'
			. '<span class="arxiv-related-media">' . $media . '</span>'
			. '<span class="arxiv-related-title">' . esc_html( get_the_title( $rel_id ) ) . '</span>'
			. '</a>'
			. '<time class="arxiv-related-date" datetime="' . esc_attr( get_the_date( 'c', $rel_id ) ) . '">' . $date . '</time>'
			. '</li>';
	}

	return arxiv_blog_compact_html(
		'<section class="arxiv-related" aria-label="' . esc_attr__( 'More arXiv news', 'arxiv-blog' ) . '">'
		. '<h2 class="arxiv-related-heading">' . esc_html__( 'More arXiv news', 'arxiv-blog' ) . '</h2>'
		. '<ul class="arxiv-related-list">' . $items . '</ul>'
		. '</section>'
	);
} );
