<?php
/**
 * Pinned featured post (Kat's request, 2026-09-11).
 *
 * The homepage gives its first post the featured layout (blog.css,
 * "Featured post"). Editors choose that post with WordPress's own
 * sticky flag on the post, and the homepage query (inherit: true, so
 * the main query) already lifts a sticky post to the top of page 1.
 * With no pin, the newest post is featured.
 *
 * The theme adds one rule: one pin at a time, because there is one
 * featured slot. stick_post() appends, so the last ID is the most
 * recently pinned; keeping only that one makes a new pin replace the
 * old. Filtering reads as well as writes covers posts pinned before
 * this rule existed.
 */

function arxiv_blog_single_sticky( $ids ) {
	return is_array( $ids ) ? array_slice( array_values( $ids ), -1 ) : $ids;
}
add_filter( 'pre_update_option_sticky_posts', 'arxiv_blog_single_sticky' );
add_filter( 'option_sticky_posts', 'arxiv_blog_single_sticky' );
