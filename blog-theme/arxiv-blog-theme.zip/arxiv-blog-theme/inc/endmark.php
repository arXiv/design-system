<?php
/**
 * Per-post "hide end mark" toggle (comms request 2026-08-05: "Kat is
 * fine with turning it off as needed" — e.g., memorial posts, where
 * the smiling end slug strikes the wrong note).
 *
 * A sidebar meta box with one checkbox; the theme adds a body class
 * and the CSS suppresses the ::after mark.
 */

const ARXIV_BLOG_ENDMARK_META = '_arxiv_hide_endmark';

add_action( 'add_meta_boxes', function () {
	add_meta_box(
		'arxiv-blog-endmark',
		__( 'arXiv News options', 'arxiv-blog' ),
		function ( $post ) {
			wp_nonce_field( 'arxiv_endmark_save', 'arxiv_endmark_nonce' );
			$hidden = get_post_meta( $post->ID, ARXIV_BLOG_ENDMARK_META, true );
			?>
			<label>
				<input type="checkbox" name="arxiv_hide_endmark" value="1" <?php checked( $hidden, '1' ); ?>>
				<?php esc_html_e( 'Hide the end-of-article mark (e.g., memorial posts)', 'arxiv-blog' ); ?>
			</label>
			<?php
		},
		'post',
		'side'
	);
} );

add_action( 'save_post_post', function ( $post_id ) {
	if ( ! isset( $_POST['arxiv_endmark_nonce'] )
		|| ! wp_verify_nonce( $_POST['arxiv_endmark_nonce'], 'arxiv_endmark_save' )
		|| ! current_user_can( 'edit_post', $post_id )
	) {
		return;
	}
	if ( empty( $_POST['arxiv_hide_endmark'] ) ) {
		delete_post_meta( $post_id, ARXIV_BLOG_ENDMARK_META );
	} else {
		update_post_meta( $post_id, ARXIV_BLOG_ENDMARK_META, '1' );
	}
} );

add_filter( 'body_class', function ( $classes ) {
	if ( is_singular( 'post' ) && '1' === get_post_meta( get_the_ID(), ARXIV_BLOG_ENDMARK_META, true ) ) {
		$classes[] = 'arxiv-no-endmark';
	}
	return $classes;
} );
