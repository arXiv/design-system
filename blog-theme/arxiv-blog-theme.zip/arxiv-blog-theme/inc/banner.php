<?php
/**
 * Announcement banner — editor-controlled, theme-native.
 *
 * Renders the design system's .ds-announcement pattern (icon + short
 * sentence + link + dismiss; see docs/public/header-styles.html).
 * Editors manage content and on/off under Settings → Announcement
 * banner — no third-party plugin, so the markup always matches the
 * design system exactly.
 *
 * Dismissal persists per user via localStorage, keyed on a hash of the
 * banner content (DESIGN-POLICIES.md, Banner): dismissing hides THIS
 * announcement for that user; publishing a new one shows again.
 */

const ARXIV_BLOG_BANNER_OPTION = 'arxiv_blog_banner';

function arxiv_blog_banner_defaults() {
	return array(
		'enabled'    => 0,
		'text'       => '',
		'url'        => '',
		'link_label' => 'Learn more',
	);
}

function arxiv_blog_banner_get() {
	$value = get_option( ARXIV_BLOG_BANNER_OPTION, array() );
	return wp_parse_args( is_array( $value ) ? $value : array(), arxiv_blog_banner_defaults() );
}

function arxiv_blog_banner_sanitize( $input ) {
	$clean               = arxiv_blog_banner_defaults();
	$clean['enabled']    = empty( $input['enabled'] ) ? 0 : 1;
	$clean['text']       = isset( $input['text'] ) ? sanitize_text_field( $input['text'] ) : '';
	$clean['url']        = isset( $input['url'] ) ? esc_url_raw( $input['url'] ) : '';
	$clean['link_label'] = isset( $input['link_label'] ) && '' !== trim( $input['link_label'] )
		? sanitize_text_field( $input['link_label'] )
		: 'Learn more';
	return $clean;
}

add_action( 'admin_init', function () {
	register_setting( 'arxiv_blog_banner', ARXIV_BLOG_BANNER_OPTION, array(
		'type'              => 'array',
		'sanitize_callback' => 'arxiv_blog_banner_sanitize',
	) );
} );

// Editors (edit_pages), not just admins, can manage the banner.
add_filter( 'option_page_capability_arxiv_blog_banner', function () {
	return 'edit_pages';
} );

add_action( 'admin_menu', function () {
	add_options_page(
		__( 'Announcement banner', 'arxiv-blog' ),
		__( 'Announcement banner', 'arxiv-blog' ),
		'edit_pages',
		'arxiv-blog-banner',
		'arxiv_blog_banner_settings_page'
	);
} );

function arxiv_blog_banner_settings_page() {
	$banner = arxiv_blog_banner_get();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Announcement banner', 'arxiv-blog' ); ?></h1>
		<p><?php esc_html_e( 'A short announcement band shown above the site header. Keep it to one sentence with an optional link. Visitors can dismiss it; it stays hidden for them until the content changes.', 'arxiv-blog' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'arxiv_blog_banner' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Show banner', 'arxiv-blog' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="<?php echo esc_attr( ARXIV_BLOG_BANNER_OPTION ); ?>[enabled]" value="1" <?php checked( $banner['enabled'], 1 ); ?>>
							<?php esc_html_e( 'Display the banner on the site', 'arxiv-blog' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="arxiv-banner-text"><?php esc_html_e( 'Announcement text', 'arxiv-blog' ); ?></label></th>
					<td><input type="text" class="large-text" id="arxiv-banner-text" name="<?php echo esc_attr( ARXIV_BLOG_BANNER_OPTION ); ?>[text]" value="<?php echo esc_attr( $banner['text'] ); ?>" placeholder="<?php esc_attr_e( 'arXiv is now an independent nonprofit!', 'arxiv-blog' ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="arxiv-banner-url"><?php esc_html_e( 'Link URL (optional)', 'arxiv-blog' ); ?></label></th>
					<td><input type="url" class="large-text" id="arxiv-banner-url" name="<?php echo esc_attr( ARXIV_BLOG_BANNER_OPTION ); ?>[url]" value="<?php echo esc_attr( $banner['url'] ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="arxiv-banner-label"><?php esc_html_e( 'Link label', 'arxiv-blog' ); ?></label></th>
					<td><input type="text" id="arxiv-banner-label" name="<?php echo esc_attr( ARXIV_BLOG_BANNER_OPTION ); ?>[link_label]" value="<?php echo esc_attr( $banner['link_label'] ); ?>"></td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/*
 * Skip link — must be the FIRST focusable element on the page
 * (header behavior contract), so it renders at wp_body_open before
 * the banner and the header template part.
 */
add_action( 'wp_body_open', function () {
	echo '<a class="ds-skip-link" href="#main">' . esc_html__( 'Skip to main content', 'arxiv-blog' ) . "</a>\n";
}, 5 );

add_action( 'wp_body_open', function () {
	$banner = arxiv_blog_banner_get();
	if ( ! $banner['enabled'] || '' === $banner['text'] ) {
		return;
	}
	// Content hash: a new announcement re-shows for users who dismissed the old one.
	$banner_id = substr( md5( $banner['text'] . '|' . $banner['url'] . '|' . $banner['link_label'] ), 0, 8 );
	?>
	<div class="ds-announcement" role="region" aria-label="<?php esc_attr_e( 'Announcement', 'arxiv-blog' ); ?>" data-arxiv-banner="<?php echo esc_attr( $banner_id ); ?>">
		<img class="ds-announcement-glyph" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/icon_small-smileybones.png' ) ); ?>" alt="" aria-hidden="true">
		<span class="ds-announcement-text"><?php echo esc_html( $banner['text'] ); ?></span>
		<?php if ( '' !== $banner['url'] ) : ?>
			<a class="ds-announcement-link" href="<?php echo esc_url( $banner['url'] ); ?>"><?php echo esc_html( $banner['link_label'] ); ?></a>
		<?php endif; ?>
		<button type="button" class="ds-announcement-close" aria-label="<?php esc_attr_e( 'Dismiss announcement', 'arxiv-blog' ); ?>">&times;</button>
	</div>
	<script>
	( function () {
		var banner = document.querySelector( '[data-arxiv-banner]' );
		if ( ! banner ) { return; }
		var KEY = 'arxivBlogBannerDismissed';
		try {
			if ( localStorage.getItem( KEY ) === banner.getAttribute( 'data-arxiv-banner' ) ) {
				banner.remove();
				return;
			}
		} catch ( e ) {}
		var close = banner.querySelector( '.ds-announcement-close' );
		close.addEventListener( 'click', function () {
			try { localStorage.setItem( KEY, banner.getAttribute( 'data-arxiv-banner' ) ); } catch ( e ) {}
			banner.remove();
		} );
	} )();
	</script>
	<?php
}, 10 );
