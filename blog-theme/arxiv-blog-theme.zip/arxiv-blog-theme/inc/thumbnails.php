<?php
/**
 * First-content-image fallback for card thumbnails.
 *
 * Most live posts have no featured image. When the featured-image
 * block renders empty, fall back to the first <img> found in the
 * post's content — display-time only, nothing is written to posts.
 * Editors can still set a real featured image to override.
 */

// First <img> src in a post's content, or '' if none.
function arxiv_blog_first_content_image( $post_id ) {
	$content = get_post_field( 'post_content', $post_id );
	if ( ! $content || ! preg_match( '/<img[^>]+src=["\']([^"\']+)["\']/i', $content, $m ) ) {
		return '';
	}
	return $m[1];
}

add_filter( 'render_block_core/post-featured-image', function ( $html, $parsed_block, $block ) {
	if ( '' !== trim( $html ) ) {
		return $html; // real featured image exists
	}
	$post_id = isset( $block->context['postId'] ) ? (int) $block->context['postId'] : 0;
	if ( ! $post_id ) {
		return $html;
	}
	$src = arxiv_blog_first_content_image( $post_id );
	if ( '' === $src ) {
		return $html; // no image anywhere — placeholder CSS handles it
	}
	$classes = 'wp-block-post-featured-image';
	if ( ! empty( $parsed_block['attrs']['className'] ) ) {
		$classes .= ' ' . $parsed_block['attrs']['className'];
	}
	$img = '<img src="' . esc_url( $src ) . '" alt="" loading="lazy">';
	if ( ! empty( $parsed_block['attrs']['isLink'] ) ) {
		$img = '<a href="' . esc_url( get_permalink( $post_id ) ) . '">' . $img . '</a>';
	}
	return '<figure class="' . esc_attr( $classes ) . '">' . $img . '</figure>';
}, 10, 3 );
