<?php
/**
 * Homepage intro + special message — editor-controlled.
 *
 * Settings → Homepage (visible to Editors, like the banner):
 *   - Welcome heading + body (the static intro, always shown)
 *   - Subscribe URL (also used by the header nav link)
 *   - Optional special message: on/off, heading, body, image, CTA link
 *
 * Rendered into templates/home.html via the [arxiv_blog_intro]
 * shortcode. The special message band uses the arXiv-chrome light-blue
 * family (Tint Light / Tint Border — "light blue = arXiv speaking",
 * color-mapping.md) and a .ds-btn-primary CTA.
 */

const ARXIV_BLOG_HOMEPAGE_OPTION = 'arxiv_blog_homepage';

/**
 * The *stars* convention: editors wrap a phrase in asterisks to set it
 * in italic (<em>) — no HTML needed. Escapes first, so the output is
 * safe to print. Shared by the welcome heading and the special-message
 * heading (each styles its own <em>).
 */
function arxiv_blog_stars_html( $text ) {
	return preg_replace( '/\*([^*]+)\*/', '<em>$1</em>', esc_html( $text ) );
}

function arxiv_blog_homepage_defaults() {
	return array(
		'intro_heading'      => 'Updates on *all*|*things* arXiv',
		'intro_body'         => 'arXiv policy changes, upcoming projects, jobs and new hires, tech improvements and outages, accessibility updates, membership, and more.',
		'subscribe_url'      => '/feed/',
		'special_enabled'    => 0, // launch-safe: editors enable deliberately (demo copy below is placeholder)
		'special_type'       => 'fundraising',
		'special_heading'    => 'Celebrate Open Access Week',
		'special_body'       => 'Support open science with a donation to arXiv. 100% of your donation goes to expanding access to research to scientists around the world.',
		'special_image'      => '', // empty = theme default (partybones)
		'special_link_url'   => 'https://info.arxiv.org/about/donate.html',
		'special_link_label' => 'Donate',
	);
}

function arxiv_blog_homepage_get() {
	$value = get_option( ARXIV_BLOG_HOMEPAGE_OPTION, array() );
	return wp_parse_args( is_array( $value ) ? $value : array(), arxiv_blog_homepage_defaults() );
}

function arxiv_blog_homepage_sanitize( $input ) {
	$d     = arxiv_blog_homepage_defaults();
	$clean = array();
	$clean['intro_heading']      = isset( $input['intro_heading'] ) ? sanitize_text_field( $input['intro_heading'] ) : $d['intro_heading'];
	$clean['intro_body']         = isset( $input['intro_body'] ) ? sanitize_textarea_field( $input['intro_body'] ) : $d['intro_body'];
	$clean['subscribe_url']      = isset( $input['subscribe_url'] ) && '' !== trim( $input['subscribe_url'] ) ? esc_url_raw( $input['subscribe_url'] ) : $d['subscribe_url'];
	$clean['special_enabled']    = empty( $input['special_enabled'] ) ? 0 : 1;
	$clean['special_type']       = isset( $input['special_type'] ) && in_array( $input['special_type'], array( 'fundraising', 'celebration', 'technical', 'custom' ), true )
		? $input['special_type']
		: 'fundraising';
	$clean['special_heading']    = isset( $input['special_heading'] ) ? sanitize_text_field( $input['special_heading'] ) : '';
	$clean['special_body']       = isset( $input['special_body'] ) ? sanitize_textarea_field( $input['special_body'] ) : '';
	$clean['special_image']      = isset( $input['special_image'] ) ? esc_url_raw( $input['special_image'] ) : '';
	$clean['special_link_url']   = isset( $input['special_link_url'] ) ? esc_url_raw( $input['special_link_url'] ) : '';
	$clean['special_link_label'] = isset( $input['special_link_label'] ) ? sanitize_text_field( $input['special_link_label'] ) : '';
	return $clean;
}

add_action( 'admin_init', function () {
	register_setting( 'arxiv_blog_homepage', ARXIV_BLOG_HOMEPAGE_OPTION, array(
		'type'              => 'array',
		'sanitize_callback' => 'arxiv_blog_homepage_sanitize',
	) );
} );

add_filter( 'option_page_capability_arxiv_blog_homepage', function () {
	return 'edit_pages';
} );

add_action( 'admin_menu', function () {
	add_options_page(
		__( 'Homepage', 'arxiv-blog' ),
		__( 'Homepage', 'arxiv-blog' ),
		'edit_pages',
		'arxiv-blog-homepage',
		'arxiv_blog_homepage_settings_page'
	);
} );

// Media Library picker for the Miscellaneous image (our settings page only).
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'settings_page_arxiv-blog-homepage' === $hook ) {
		wp_enqueue_media();
	}
} );

function arxiv_blog_homepage_settings_page() {
	$h    = arxiv_blog_homepage_get();
	$name = ARXIV_BLOG_HOMEPAGE_OPTION;
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Homepage', 'arxiv-blog' ); ?></h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'arxiv_blog_homepage' ); ?>

			<h2><?php esc_html_e( 'Welcome message', 'arxiv-blog' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="hp-heading"><?php esc_html_e( 'Heading', 'arxiv-blog' ); ?></label></th>
					<td>
						<input type="text" class="large-text" id="hp-heading" name="<?php echo esc_attr( $name ); ?>[intro_heading]" value="<?php echo esc_attr( $h['intro_heading'] ); ?>">
						<p class="description"><?php esc_html_e( 'Type | to force a line break and *stars* around a phrase to set it in italic. The word "arXiv" gets the drawn circle automatically.', 'arxiv-blog' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="hp-body"><?php esc_html_e( 'Body', 'arxiv-blog' ); ?></label></th>
					<td><textarea class="large-text" rows="3" id="hp-body" name="<?php echo esc_attr( $name ); ?>[intro_body]"><?php echo esc_textarea( $h['intro_body'] ); ?></textarea></td>
				</tr>
				<tr>
					<th scope="row"><label for="hp-subscribe"><?php esc_html_e( 'Subscribe URL', 'arxiv-blog' ); ?></label></th>
					<td>
						<input type="text" class="large-text" id="hp-subscribe" name="<?php echo esc_attr( $name ); ?>[subscribe_url]" value="<?php echo esc_attr( $h['subscribe_url'] ); ?>">
						<p class="description"><?php esc_html_e( 'Used by the header "Subscribe" link and the welcome area. Point it at the page with the email signup form; /feed/ (RSS) is the fallback default.', 'arxiv-blog' ); ?></p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Special message', 'arxiv-blog' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Show special message', 'arxiv-blog' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="<?php echo esc_attr( $name ); ?>[special_enabled]" value="1" <?php checked( $h['special_enabled'], 1 ); ?>>
							<?php esc_html_e( 'Display the special message on the homepage', 'arxiv-blog' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="hp-sp-heading"><?php esc_html_e( 'Heading', 'arxiv-blog' ); ?></label></th>
					<td>
						<input type="text" class="large-text" id="hp-sp-heading" name="<?php echo esc_attr( $name ); ?>[special_heading]" value="<?php echo esc_attr( $h['special_heading'] ); ?>">
						<p class="description"><?php esc_html_e( 'Put *stars* around a word to set it in italic.', 'arxiv-blog' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="hp-sp-body"><?php esc_html_e( 'Body', 'arxiv-blog' ); ?></label></th>
					<td><textarea class="large-text" rows="3" id="hp-sp-body" name="<?php echo esc_attr( $name ); ?>[special_body]"><?php echo esc_textarea( $h['special_body'] ); ?></textarea></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Message type', 'arxiv-blog' ); ?></th>
					<td>
						<?php
						$types = array(
							'fundraising' => __( 'Fundraising — shows the Giving Seal', 'arxiv-blog' ),
							'celebration' => __( 'Holiday / celebration — shows the partybones badge', 'arxiv-blog' ),
							'technical'   => __( 'Technical update — shows the toolybones badge', 'arxiv-blog' ),
							'custom'      => __( 'Miscellaneous — uses the image URL below', 'arxiv-blog' ),
						);
						foreach ( $types as $value => $label ) :
							?>
							<label style="display:block;margin-bottom:4px;">
								<input type="radio" name="<?php echo esc_attr( $name ); ?>[special_type]" value="<?php echo esc_attr( $value ); ?>" <?php checked( $h['special_type'], $value ); ?>>
								<?php echo esc_html( $label ); ?>
							</label>
						<?php endforeach; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="hp-sp-image"><?php esc_html_e( 'Image (Miscellaneous only)', 'arxiv-blog' ); ?></label></th>
					<td>
						<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
							<input type="text" class="regular-text" id="hp-sp-image" name="<?php echo esc_attr( $name ); ?>[special_image]" value="<?php echo esc_attr( $h['special_image'] ); ?>" style="flex:1;min-width:280px;">
							<button type="button" class="button" id="hp-sp-image-select"><?php esc_html_e( 'Select image', 'arxiv-blog' ); ?></button>
							<button type="button" class="button" id="hp-sp-image-clear"><?php esc_html_e( 'Clear', 'arxiv-blog' ); ?></button>
						</div>
						<p class="description"><?php esc_html_e( 'Any size works — it is fitted to a fixed square and cropped (never stretched). Ignored unless the type above is Miscellaneous.', 'arxiv-blog' ); ?></p>
						<img id="hp-sp-image-preview" src="<?php echo esc_url( $h['special_image'] ); ?>" alt="" style="max-width:140px;max-height:140px;margin-top:8px;border:1px solid #ddd8d2;border-radius:4px;<?php echo '' === $h['special_image'] ? 'display:none;' : ''; ?>">
						<script>
						( function () {
							var btn     = document.getElementById( 'hp-sp-image-select' );
							var clear   = document.getElementById( 'hp-sp-image-clear' );
							var field   = document.getElementById( 'hp-sp-image' );
							var preview = document.getElementById( 'hp-sp-image-preview' );
							if ( ! btn ) { return; }
							// wp.media loads in the admin footer, after this inline
							// script — so test for it at click time, not bind time.
							var frame;
							function setPreview( url ) {
								preview.src = url || '';
								preview.style.display = url ? 'inline-block' : 'none';
							}
							btn.addEventListener( 'click', function ( e ) {
								e.preventDefault();
								if ( ! window.wp || ! wp.media ) { return; }
								if ( ! frame ) {
									frame = wp.media( {
										title: '<?php echo esc_js( __( 'Select special message image', 'arxiv-blog' ) ); ?>',
										button: { text: '<?php echo esc_js( __( 'Use this image', 'arxiv-blog' ) ); ?>' },
										library: { type: 'image' },
										multiple: false
									} );
									frame.on( 'select', function () {
										var att = frame.state().get( 'selection' ).first().toJSON();
										var url = ( att.sizes && att.sizes.large ) ? att.sizes.large.url : att.url;
										field.value = url;
										setPreview( url );
									} );
								}
								frame.open();
							} );
							clear.addEventListener( 'click', function () {
								field.value = '';
								setPreview( '' );
							} );
							field.addEventListener( 'input', function () { setPreview( field.value ); } );
						} )();
						</script>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="hp-sp-url"><?php esc_html_e( 'Link URL', 'arxiv-blog' ); ?></label></th>
					<td><input type="text" class="large-text" id="hp-sp-url" name="<?php echo esc_attr( $name ); ?>[special_link_url]" value="<?php echo esc_attr( $h['special_link_url'] ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="hp-sp-label"><?php esc_html_e( 'Link label', 'arxiv-blog' ); ?></label></th>
					<td><input type="text" id="hp-sp-label" name="<?php echo esc_attr( $name ); ?>[special_link_label]" value="<?php echo esc_attr( $h['special_link_label'] ); ?>"></td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

// [arxiv_blog_intro] — the homepage welcome + optional special message.
add_shortcode( 'arxiv_blog_intro', function () {
	$h   = arxiv_blog_homepage_get();
	/*
	 * Type → image + frame treatment. Sticker types (transparent icons)
	 * render bare; a custom upload gets the "tilted print" frame and is
	 * object-fit:cover cropped to the fixed box. Same tilt + overhang
	 * geometry for every type.
	 */
	$type_images = array(
		'fundraising' => 'assets/images/icon_giving-seal-badge.png',
		'celebration' => 'assets/images/icon_partybones-badge.png',
		'technical'   => 'assets/images/icon_toolybones-badge.png',
	);
	$type = $h['special_type'];
	if ( 'custom' === $type && '' === $h['special_image'] ) {
		$type = 'fundraising'; // no upload yet — fall back to the seal
	}
	$img_style = '';
	if ( 'custom' === $type ) {
		$img       = $h['special_image'];
		$img_class = 'arxiv-special-img arxiv-special-img--print';
	} else {
		$img       = get_theme_file_uri( $type_images[ $type ] );
		$img_class = 'arxiv-special-img arxiv-special-img--sticker';
		/*
		 * Badge contract: the circle spans the image's full WIDTH; any
		 * extra height is decoration ABOVE it (partybones' hat). The
		 * stacked medallion pins the CIRCLE to the card's top edge, so
		 * hand CSS the decoration's rendered height (at the 152px box)
		 * to subtract — otherwise a hat pushes the circle off the edge.
		 */
		$size = getimagesize( get_theme_file_path( $type_images[ $type ] ) );
		if ( $size && $size[0] > 0 && $size[1] > $size[0] ) {
			$img_style = sprintf( '--arxiv-badge-hat:%.1fpx', 152 * $size[1] / $size[0] - 152 );
		}
	}
	ob_start();
	?>
	<?php
	/*
	 * Headline rendering (hero redesign, Shamsi 2026-08-11). The heading
	 * stays an editable setting; two light conventions give editors
	 * art-direction without HTML: "|" forces a line break, *stars* set a
	 * phrase in serif italic. The first "arXiv" gets the hand-drawn ink
	 * circle (draw-on animation; static under prefers-reduced-motion).
	 */
	$heading = arxiv_blog_stars_html( $h['intro_heading'] );
	// |-designed lines become nowrap segments (they may borrow the
	// column gap); a heading without | wraps naturally.
	if ( false !== strpos( $heading, '|' ) ) {
		$heading = '<span class="arxiv-hline">'
			. implode( '</span><br><span class="arxiv-hline">', explode( '|', $heading ) )
			. '</span>';
	}
	$circle_svg = '<svg class="arxiv-circle" viewBox="0 0 200 80" fill="none" aria-hidden="true" focusable="false">'
		. '<path d="M28,42 C22,16 78,6 116,10 C166,15 186,28 183,45 C180,66 128,75 82,72 C38,69 12,58 26,36 C31,28 44,22 58,19" '
		. 'stroke="#ffe000" stroke-width="2.25" stroke-linecap="round"/></svg>';
	$heading = preg_replace(
		'/\barXiv\b/',
		'<span class="arxiv-circled">arXiv' . $circle_svg . '</span>',
		$heading,
		1
	);
	?>
	<div class="arxiv-intro">
		<div class="arxiv-intro-main">
			<h1 class="arxiv-intro-heading"><?php echo $heading; // phpcs:ignore -- escaped above, then decorated ?></h1>
		</div>
		<div class="arxiv-intro-side">
			<p class="arxiv-intro-body"><?php echo esc_html( $h['intro_body'] ); ?></p>
			<p class="arxiv-intro-subscribe">
				<?php // Secondary button — Donate in the special message holds
				      // the band's one primary. ?>
				<a class="ds-btn arxiv-btn-ghost" href="<?php echo esc_url( $h['subscribe_url'] ); ?>">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/></svg>
					<?php esc_html_e( 'Subscribe', 'arxiv-blog' ); ?>
				</a>
			</p>
		</div>
	</div>
	<?php if ( $h['special_enabled'] && '' !== $h['special_heading'] ) : ?>
	<?php // aria-label reads the plain text — stars are visual markup. ?>
	<aside class="arxiv-special" aria-label="<?php echo esc_attr( str_replace( '*', '', $h['special_heading'] ) ); ?>">
		<img class="<?php echo esc_attr( $img_class ); ?>"<?php echo $img_style ? ' style="' . esc_attr( $img_style ) . '"' : ''; ?> src="<?php echo esc_url( $img ); ?>" alt="">
		<div class="arxiv-special-content">
			<h2 class="arxiv-special-heading"><?php echo arxiv_blog_stars_html( $h['special_heading'] ); // phpcs:ignore -- escaped inside ?></h2>
			<p class="arxiv-special-body"><?php echo esc_html( $h['special_body'] ); ?></p>
			<?php if ( '' !== $h['special_link_url'] && '' !== $h['special_link_label'] ) : ?>
				<a class="ds-btn ds-btn-primary" href="<?php echo esc_url( $h['special_link_url'] ); ?>"><?php echo esc_html( $h['special_link_label'] ); ?></a>
			<?php endif; ?>
		</div>
	</aside>
	<?php endif;
	return arxiv_blog_compact_html( ob_get_clean() );
} );
