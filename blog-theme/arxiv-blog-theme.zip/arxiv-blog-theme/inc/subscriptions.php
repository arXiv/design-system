<?php
/**
 * Subscription-aware touches.
 *
 * Both features key off the same check the Subscribe block itself uses
 * (Jetpack_Memberships::is_current_user_subscribed()), so the theme and
 * the block always agree about who counts as subscribed. Everything is
 * guarded with class_exists — locally (wp-now, no Jetpack) the theme
 * behaves as if nobody is subscribed.
 *
 * Cache note: only logged-in visitors can test true, and logged-in
 * views bypass WordPress.com's page cache — the shared cached pages
 * always carry the un-subscribed markup, so nothing leaks.
 */

/**
 * Is the current visitor a logged-in, already-subscribed reader?
 */
function arxiv_blog_is_subscriber() {
	return class_exists( 'Jetpack_Memberships' )
		&& method_exists( 'Jetpack_Memberships', 'is_current_user_subscribed' )
		&& Jetpack_Memberships::is_current_user_subscribed();
}

/*
 * The Subscribe block's already-subscribed state renders a "Subscribed"
 * pseudo-button linking off-site to the WordPress.com Reader — poor fit
 * for the blog (Shamsi 2026-08-13). Replace the block's output for
 * subscribed readers with a plain message and a route back home.
 * Everyone else (including email subscribers who aren't logged in)
 * gets the normal form.
 */
add_filter( 'render_block_jetpack/subscriptions', function ( $content ) {
	if ( ! arxiv_blog_is_subscriber() ) {
		return $content;
	}
	return '<div class="arxiv-already-subscribed">'
		. '<p>' . esc_html__( 'You are already subscribed!', 'arxiv-blog' ) . '</p>'
		. '<a class="ds-btn ds-btn-secondary" href="' . esc_url( home_url( '/' ) ) . '">'
		. esc_html__( 'Back to the homepage', 'arxiv-blog' ) . '</a>'
		. '</div>';
} );
